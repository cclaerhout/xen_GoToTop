**********************************
* GoToTop! v.1.1                 *
* by C�dric CLAERHOUT            *
**********************************

**********************************
*      Addon Presentation        *
**********************************
This addon inserts a floating button at the right of the footer helping users to go to the top of the page
I've seen this addon on many websites and I really like it. Matt Varone, the creator of the Javascript, really did a great job.

What's new with that XenForo options?
> Many colors available: black, white, blue, green, red, purple & Chameleon
> The Chamelon color is a button that should update to any themes
> Two buttons types: normal(big) and mini (small)
> These buttons are using PNG 32 except for IE6 (a black button in PNG8 is automatically used)
> All PNG have been optimized (original image size : 56ko. Now: less than 2ko)
> The psd files of these buttons are provided
> The scrolling-top effect can easily be configured 
> This addon can be configured differently for each of your styles (thanks to XenForo architecture)
> The original Javascript has been slightly modified to make it compatible with the default Jquery that is using XenForo

> Mobile option (v1.1)
> Tablet option (v1.1) => need to install this addon: http://xenforo.com/community/resources/browser-detection-mobile-msie.1098/

Tested on
Firefox, Opera, Chrome, IE9, IE8, IE7, IE6, Dolphin (Ipad)



**********************************
*         Installation           *
**********************************
1) Upload the files on your forum directory
2) Import xml file


**********************************
*        Configuration           *
**********************************
To activate  & configurate this addon, you must got to XenForo appearance options:
AdminCp=>Appearance=>Style properties=>(Select your style)=>Go To Top! (at the bottom)

**********************************
*          References            *
**********************************
Matt Varone Javascript: http://www.mattvarone.com


